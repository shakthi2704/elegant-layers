
import Image from "next/image"
import { LoginForm } from "@/components/auth/login-form"

export default function Page() {
    return (
        <div className="flex min-h-svh w-full items-center justify-center p-6 md:p-10">
            <div className="w-full max-w-sm">
                <div className="mb-6 flex justify-center">
                    <Image
                        src="/logo/logo.jpeg"
                        alt="Logo"
                        width={120}
                        height={120}
                        className="h-auto w-auto"
                        priority
                    />
                </div>

                <LoginForm />
            </div>
        </div>
    )
}

