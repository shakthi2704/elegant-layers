import { redirect } from "next/navigation";
import { headers } from "next/headers";

import { auth } from "@/lib/auth";

import { TooltipProvider } from "@/components/ui/tooltip";
import { AppSidebar } from "@/components/sidebar/app-sidebar";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth.api.getSession({ headers: await headers() });

  if (!session) {
    redirect("/sign-in");
  }

  const user = session.user as typeof session.user & {
    role: "ADMIN" | "CASHIER";
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <AppSidebar role={user.role} />
      <div className="flex flex-1 flex-col overflow-hidden">

        <main className="flex-1 overflow-y-auto bg-background p-6">
          <TooltipProvider>{children}</TooltipProvider>
        </main>
      </div>
    </div >
  );
}
