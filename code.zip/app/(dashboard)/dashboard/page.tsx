import { ComingSoon } from "@/components/layout/coming-soon";

export default function DashboardPage() {
  return <>test</>;
}
